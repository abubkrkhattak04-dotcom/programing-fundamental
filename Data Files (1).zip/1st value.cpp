#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>

// ============================================================================
// GLOBAL SYSTEM CONSTANTS & STRUCTURES (No Classes, No STL Containers)
// ============================================================================
const int MAX_RECORDS = 1500; // Increased to comfortably accommodate up to 1200+ attendance log rows

struct Student {
    std::string roll_no;
    std::string name;
    std::string department;
    std::string semester;
    double cgpa;
    std::string status; // active, inactive
};

struct Course {
    std::string course_code;
    std::string course_name;
    int credit_hours;
    std::string instructor;
    int capacity;
    int enrolled;
    std::string prerequisite;
};

struct Enrollment {
    std::string enrollment_id;
    std::string roll_no;
    std::string course_code;
    std::string semester;
    std::string enrollment_date;
    std::string status; // active, dropped
};

struct AttendanceLog {
    std::string log_id;
    std::string roll_no;
    std::string course_code;
    std::string session_date;
    std::string status; // P, A, L
};

struct FeeRecord {
    std::string fee_id;
    std::string roll_no;
    std::string semester;
    double total_fee;
    double amount_paid;
    std::string due_date;
    std::string payment_date;
    std::string payment_method;
    std::string status; // paid, paid_late, unpaid, partial
};

// Global backup array for Attendance Module Rollback
AttendanceLog attendanceBackup[MAX_RECORDS];
int backupSize = 0;

// ============================================================================
// M1: CUSTOM FILE PARSER MODULE
// ============================================================================
int parseCSVLine(const std::string& line, std::string fields[], int maxFields) {
    int count = 0;
    std::string current = "";
    bool inQuotes = false;

    for (size_t i = 0; i < line.length(); i++) {
        char ch = line[i];
        if (ch == '\r' || ch == '\n') continue; // Strip line breaks cleanly
        
        if (ch == '"') {
            inQuotes = !inQuotes;
        } else if (ch == ',' && !inQuotes) {
            if (count < maxFields) fields[count++] = current;
            current = "";
        } else {
            current += ch;
        }
    }
    if (count < maxFields) fields[count++] = current;
    return count;
}

// Data loaders mapping precisely to matching database text layouts
int loadStudents(Student arr[]) {
    std::ifstream file("students.txt");
    if (!file.is_open()) return 0;
    std::string line;
    std::getline(file, line); // Skip columns header
    int count = 0;
    while (std::getline(file, line) && count < MAX_RECORDS) {
        std::string fields[6];
        parseCSVLine(line, fields, 6);
        arr[count].roll_no = fields[0];
        arr[count].name = fields[1];
        arr[count].department = fields[2];
        arr[count].semester = fields[3];
        arr[count].cgpa = std::stod(fields[4]);
        arr[count].status = fields[5];
        count++;
    }
    file.close();
    return count;
}

void writeStudents(Student arr[], int count) {
    std::ofstream file("students.txt");
    file << "roll_no,name,department,semester,cgpa,status\n";
    for (int i = 0; i < count; i++) {
        file << arr[i].roll_no << "," << arr[i].name << "," << arr[i].department << "," 
             << arr[i].semester << "," << arr[i].cgpa << "," << arr[i].status << "\n";
    }
    file.close();
}

int loadCourses(Course arr[]) {
    std::ifstream file("courses.txt");
    if (!file.is_open()) return 0;
    std::string line;
    std::getline(file, line);
    int count = 0;
    while (std::getline(file, line) && count < MAX_RECORDS) {
        std::string fields[7];
        parseCSVLine(line, fields, 7);
        arr[count].course_code = fields[0];
        arr[count].course_name = fields[1];
        arr[count].credit_hours = std::stoi(fields[2]);
        arr[count].instructor = fields[3];
        arr[count].capacity = std::stoi(fields[4]);
        arr[count].enrolled = std::stoi(fields[5]);
        arr[count].prerequisite = fields[6];
        count++;
    }
    file.close();
    return count;
}

void writeCourses(Course arr[], int count) {
    std::ofstream file("courses.txt");
    file << "course_code,course_name,credit_hours,instructor,capacity,enrolled,prerequisite\n";
    for (int i = 0; i < count; i++) {
        file << arr[i].course_code << "," << arr[i].course_name << "," << arr[i].credit_hours << "," 
             << arr[i].instructor << "," << arr[i].capacity << "," << arr[i].enrolled << "," << arr[i].prerequisite << "\n";
    }
    file.close();
}

int loadEnrollments(Enrollment arr[]) {
    std::ifstream file("enrollments.txt");
    if (!file.is_open()) return 0;
    std::string line;
    std::getline(file, line);
    int count = 0;
    while (std::getline(file, line) && count < MAX_RECORDS) {
        std::string fields[6];
        parseCSVLine(line, fields, 6);
        arr[count].enrollment_id = fields[0];
        arr[count].roll_no = fields[1];
        arr[count].course_code = fields[2];
        arr[count].semester = fields[3];
        arr[count].enrollment_date = fields[4];
        arr[count].status = fields[5];
        count++;
    }
    file.close();
    return count;
}

void writeEnrollments(Enrollment arr[], int count) {
    std::ofstream file("enrollments.txt");
    file << "enrollment_id,roll_no,course_code,semester,enrollment_date,status\n";
    for (int i = 0; i < count; i++) {
        file << arr[i].enrollment_id << "," << arr[i].roll_no << "," << arr[i].course_code << "," 
             << arr[i].semester << "," << arr[i].enrollment_date << "," << arr[i].status << "\n";
    }
    file.close();
}

int loadAttendance(AttendanceLog arr[]) {
    std::ifstream file("attendance_log.txt");
    if (!file.is_open()) return 0;
    std::string line;
    std::getline(file, line);
    int count = 0;
    while (std::getline(file, line) && count < MAX_RECORDS) {
        std::string fields[5];
        parseCSVLine(line, fields, 5);
        arr[count].log_id = fields[0];
        arr[count].roll_no = fields[1];
        arr[count].course_code = fields[2];
        arr[count].session_date = fields[3];
        arr[count].status = fields[4];
        count++;
    }
    file.close();
    return count;
}

void writeAttendance(AttendanceLog arr[], int count) {
    std::ofstream file("attendance_log.txt");
    file << "log_id,roll_no,course_code,session_date,status\n";
    for (int i = 0; i < count; i++) {
        file << arr[i].log_id << "," << arr[i].roll_no << "," << arr[i].course_code << "," 
             << arr[i].session_date << "," << arr[i].status << "\n";
    }
    file.close();
}

int loadFees(FeeRecord arr[]) {
    std::ifstream file("fees.txt");
    if (!file.is_open()) return 0;
    std::string line;
    std::getline(file, line);
    int count = 0;
    while (std::getline(file, line) && count < MAX_RECORDS) {
        std::string fields[9];
        parseCSVLine(line, fields, 9);
        arr[count].fee_id = fields[0];
        arr[count].roll_no = fields[1];
        arr[count].semester = fields[2];
        arr[count].total_fee = std::stod(fields[3]);
        arr[count].amount_paid = std::stod(fields[4]);
        arr[count].due_date = fields[5];
        arr[count].payment_date = fields[6];
        arr[count].payment_method = fields[7];
        arr[count].status = fields[8];
        count++;
    }
    file.close();
    return count;
}

void writeFees(FeeRecord arr[], int count) {
    std::ofstream file("fees.txt");
    file << "fee_id,roll_no,semester,total_fee,amount_paid,due_date,payment_date,payment_method,status\n";
    for (int i = 0; i < count; i++) {
        file << arr[i].fee_id << "," << arr[i].roll_no << "," << arr[i].semester << "," << arr[i].total_fee << "," 
             << arr[i].amount_paid << "," << arr[i].due_date << "," << arr[i].payment_date << "," 
             << arr[i].payment_method << "," << arr[i].status << "\n";
    }
    file.close();
}

// ============================================================================
// M2: STUDENT PROFILES OPERATIONS MODULE
// ============================================================================
bool validateRollNumberFormat(const std::string& roll) {
    if (roll.length() != 11) return false;
    if (roll.substr(0, 5) != "BSAI-") return false;
    if (roll[7] != '-') return false;
    if (!isdigit(roll[5]) || !isdigit(roll[6])) return false;
    if (!isdigit(roll[8]) || !isdigit(roll[9]) || !isdigit(roll[10])) return false;
    return true;
}

void addStudentRecord() {
    Student s;
    std::cout << "Enter Roll Number (e.g., BSAI-23-026): ";
    std::cin >> s.roll_no;
    if (!validateRollNumberFormat(s.roll_no)) {
        std::cout << "[Validation Error] Invalid Roll Number Structure.\n";
        return;
    }

    Student records[MAX_RECORDS];
    int count = loadStudents(records);
    for (int i = 0; i < count; i++) {
        if (records[i].roll_no == s.roll_no) {
            std::cout << "[Validation Error] Primary Key Conflict: Student already exists.\n";
            return;
        }
    }

    std::cout << "Enter Student Full Name: ";
    std::cin.ignore();
    std::getline(std::cin, s.name);
    for (char c : s.name) {
        if (isdigit(c)) {
            std::cout << "[Validation Error] Student names cannot contain numbers.\n";
            return;
        }
    }

    std::cout << "Enter Department: ";
    std::getline(std::cin, s.department);
    std::cout << "Enter Semester (Numeric Code): ";
    std::cin >> s.semester;
    std::cout << "Enter Entering CGPA (0.00 to 4.00): ";
    std::cin >> s.cgpa;
    if (s.cgpa < 0.0 || s.cgpa > 4.0) {
        std::cout << "[Validation Error] CGPA out of allowed bounds.\n";
        return;
    }
    s.status = "active";

    std::ofstream file("students.txt", std::ios::app);
    file << s.roll_no << "," << s.name << "," << s.department << "," << s.semester << "," << s.cgpa << "," << s.status << "\n";
    file.close();
    std::cout << "[Success] Student profile added successfully.\n";
}

void searchAsYouTypeDirectory() {
    std::cout << "\n=== Interactive Filter Engine (Press Enter after each char, send '=' to terminate) ===\n";
    std::string stringPrefix = "";
    char singleChar;
    Student students[MAX_RECORDS];
    int count = loadStudents(students);

    while (true) {
        std::cout << "Add character query node: ";
        std::cin >> singleChar;
        if (singleChar == '=') break;
        stringPrefix += singleChar;

        std::cout << "\nMatching Students beginning with \"" << stringPrefix << "\":\n";
        bool elementsMatched = false;
        for (int i = 0; i < count; i++) {
            if (students[i].name.length() >= stringPrefix.length()) {
                // Perform a case-insensitive check by converting on the fly
                std::string subStrName = students[i].name.substr(0, stringPrefix.length());
                bool identical = true;
                for (size_t k = 0; k < stringPrefix.length(); k++) {
                    if (tolower(subStrName[k]) != tolower(stringPrefix[k])) {
                        identical = false;
                        break;
                    }
                }
                if (identical) {
                    std::cout << "  -> " << students[i].roll_no << " | " << students[i].name << " (" << students[i].status << ")\n";
                    elementsMatched = true;
                }
            }
        }
        if (!elementsMatched) std::cout << "  No existing index matched.\n";
    }
}

void softDeleteStudentRecord() {
    std::string targetRoll;
    std::cout << "Enter Student Roll Number to soft-delete: ";
    std::cin >> targetRoll;

    Student records[MAX_RECORDS];
    int count = loadStudents(records);
    bool databaseAltered = false;

    for (int i = 0; i < count; i++) {
        if (records[i].roll_no == targetRoll) {
            records[i].status = "inactive";
            databaseAltered = true;
            break;
        }
    }

    if (databaseAltered) {
        writeStudents(records, count);
        std::cout << "[Success] Student state toggled to 'inactive'.\n";
    } else {
        std::cout << "[Error] Target profile not located.\n";
    }
}

// ============================================================================
// M3: COURSE & ENROLLMENT CONTROL MODULE
// ============================================================================
int calculateActiveCreditLoad(const std::string& roll, const std::string& currentSemester) {
    Enrollment logs[MAX_RECORDS];
    Course subjects[MAX_RECORDS];
    int eLen = loadEnrollments(logs);
    int cLen = loadCourses(subjects);

    int runningCredits = 0;
    for (int i = 0; i < eLen; i++) {
        if (logs[i].roll_no == roll && logs[i].semester == currentSemester && logs[i].status == "active") {
            for (int j = 0; j < cLen; j++) {
                if (subjects[j].course_code == logs[i].course_code) {
                    runningCredits += subjects[j].credit_hours;
                }
            }
        }
    }
    return runningCredits;
}

void processCourseEnrollment() {
    std::string roll, targetCode, sem;
    std::cout << "Enter Roll Number: "; std::cin >> roll;
    std::cout << "Enter Course Code: "; std::cin >> targetCode;
    std::cout << "Enter Registration Semester: "; std::cin >> sem;

    Student students[MAX_RECORDS];
    Course courses[MAX_RECORDS];
    Enrollment enrollments[MAX_RECORDS];
    
    int sCount = loadStudents(students);
    int cCount = loadCourses(courses);
    int eCount = loadEnrollments(enrollments);

    bool isProfileVerified = false;
    for (int i = 0; i < sCount; i++) {
        if (students[i].roll_no == roll && students[i].status == "active") isProfileVerified = true;
    }
    if (!isProfileVerified) { std::cout << "[Aborted] Student profile is inactive or non-existent.\n"; return; }

    int targetCourseIndex = -1;
    for (int i = 0; i < cCount; i++) {
        if (courses[i].course_code == targetCode) targetCourseIndex = i;
    }
    if (targetCourseIndex == -1) { std::cout << "[Aborted] Selected Course code does not exist.\n"; return; }

    int currentClassSize = 0;
    for (int i = 0; i < eCount; i++) {
        if (enrollments[i].course_code == targetCode && enrollments[i].status == "active") currentClassSize++;
        if (enrollments[i].roll_no == roll && enrollments[i].course_code == targetCode && enrollments[i].status == "active") {
            std::cout << "[Aborted] Student is already actively registered in this course.\n";
            return;
        }
    }

    if (currentClassSize >= courses[targetCourseIndex].capacity) {
        std::cout << "[Aborted] Registration failed: Class is full.\n";
        return;
    }

    if (calculateActiveCreditLoad(roll, sem) + courses[targetCourseIndex].credit_hours > 21) {
        std::cout << "[Aborted] Credit hour threshold violated (>21 maximum allowed cap).\n";
        return;
    }

    // Prerequisite Verification
    if (courses[targetCourseIndex].prerequisite != "NONE") {
        bool prerequisiteCleared = false;
        for (int i = 0; i < eCount; i++) {
            if (enrollments[i].roll_no == roll && 
                enrollments[i].course_code == courses[targetCourseIndex].prerequisite && 
                enrollments[i].status == "active") {
                prerequisiteCleared = true;
                break;
            }
        }
        if (!prerequisiteCleared) {
            std::cout << "[Aborted] Prerequisite Missing: Requires " << courses[targetCourseIndex].prerequisite << "\n";
            return;
        }
    }

    // Increment allocation updates inside standard matrices
    courses[targetCourseIndex].enrolled += 1;
    writeCourses(courses, cCount);

    std::string newId = "E" + std::to_string(1000 + eCount);
    std::ofstream file("enrollments.txt", std::ios::app);
    file << newId << "," << roll << "," << targetCode << "," << sem << ",25-06-2026,active\n";
    file.close();
    std::cout << "[Success] Enrollment transaction completed successfully.\n";
}

// ============================================================================
// M4: ATTENDANCE TRACKER MODULE
// ============================================================================
void logAttendanceSheet() {
    std::string code, date;
    std::cout << "Enter Target Course Code: "; std::cin >> code;
    std::cout << "Enter Session Log Date (DD-MM-YYYY): "; std::cin >> date;

    Enrollment enrollments[MAX_RECORDS];
    int eCount = loadEnrollments(enrollments);

    AttendanceLog logs[MAX_RECORDS];
    int lCount = loadAttendance(logs);
    
    // Snapshot original logs array state for future data restoration tasks
    backupSize = lCount;
    for (int i = 0; i < lCount; i++) {
        attendanceBackup[i] = logs[i];
    }

    std::ofstream file("attendance_log.txt", std::ios::app);
    int generatedLogCount = lCount + 1;
    for (int i = 0; i < eCount; i++) {
        if (enrollments[i].course_code == code && enrollments[i].status == "active") {
            char statMark;
            std::cout << "  Mark performance for " << enrollments[i].roll_no << " (P/A/L): ";
            std::cin >> statMark;
            
            std::string logId = "L" + std::to_string(10000 + generatedLogCount++);
            file << logId << "," << enrollments[i].roll_no << "," << code << "," << date << "," << statMark << "\n";
        }
    }
    file.close();
    std::cout << "[Success] Session roster written. Backup checkpoint updated.\n";
}

void executeAttendanceRollback() {
    if (backupSize == 0) {
        std::cout << "[Error]
